package Rec.repository;

import Rec.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {

    public List<Produto> findByProduto(Produto produto);
    public List<Produto> findByProdutoIn(List<Produto> produtos);

}
