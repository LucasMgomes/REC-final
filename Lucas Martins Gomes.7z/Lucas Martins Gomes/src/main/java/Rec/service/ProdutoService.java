package Rec.service;

import Rec.model.Produto;

import java.util.List;

public interface ProdutoService {

    public List<Produto> findAll();
    public Produto findById(Long id);

    public List<Produto> findByProduto(Produto produto);
    public List<Produto> findByAlunoIn(List<Produto> produtos);

    public boolean save(Produto conteudo);
    public boolean deleteById(Long id);


}
